const {test}=require('node:test');const assert=require('node:assert/strict');
const {harness,deferred,tick}=require('./helpers/screen-actions.cjs');
const pairing='features/connections/screens/';
test('request consent: concurrent accept/decline submits only the first intent',async()=>{
 const gate=deferred(),calls=[];const h=harness(pairing+'RequestScreen.tsx',{'../api/connections':{respondToRequest:async data=>{calls.push(data);return gate.promise}}});
 const accept=h.find('accept').props.onPress,decline=h.find('decline').props.onPress;const pending=[accept(),decline(),accept()];
 assert.equal(calls.length,1);gate.resolve({connectionId:'chat1'});await Promise.all(pending);assert.equal(h.navigationCalls.length,1);
});
test('request failure releases the synchronous guard for an explicit retry',async()=>{let calls=0;const h=harness(pairing+'RequestScreen.tsx',{'../api/connections':{respondToRequest:async()=>{if(++calls===1)throw Error('offline');return{connectionId:'chat1'}}}});await h.find('accept').props.onPress();await h.find('accept').props.onPress();assert.equal(calls,2);assert.equal(h.navigationCalls.length,1)});
test('code cancel button and system back share one immediate operation',async()=>{const gate=deferred();let calls=0;const h=harness(pairing+'CodeScreen.tsx',{'../api/connections':{deactivateTid:async()=>{calls++;return gate.promise}}});const p=h.find('cancel-code').props.onPress();h.back();h.back();assert.equal(calls,1);gate.resolve({});await p;await tick();assert.equal(h.navigationCalls.length,1)});
async function enter(overrides){const h=harness(pairing+'EnterCodeScreen.tsx',overrides);await tick();h.find('code-box-0').props.onChangeText('AB12');h.find('name-input').props.onChangeText('Peer');return h;}
test('redeem same-render rapid taps perform one location lookup and one API call',async()=>{const gate=deferred();let calls=0,locations=0;const h=await enter({'../api/connections':{redeemTid:async()=>{calls++;return gate.promise}},'../../../services/location':{getCurrentLocation:async()=>{locations++;return{lat:28.6,lng:77.2}}}});const press=h.find('connect').props.onPress,p=[press(),press(),press()];await tick();assert.equal(locations,1);assert.equal(calls,1);gate.resolve({requestId:'r',expiresAt:Date.now()+300000});await Promise.all(p)});
test('lost redemption acknowledgement retries the same intent key; edited input rotates it',async()=>{const calls=[];const h=await enter({'../api/connections':{redeemTid:async data=>{calls.push(data);throw Error('lost ACK')}}});await h.find('connect').props.onPress();await h.find('connect').props.onPress();assert.ok(calls[0].redemptionId);assert.equal(calls[0].redemptionId,calls[1].redemptionId);h.find('code-box-0').props.onChangeText('CD34');await h.find('connect').props.onPress();assert.notEqual(calls[0].redemptionId,calls[2].redemptionId);h.find('name-input').props.onChangeText('Other');await h.find('connect').props.onPress();assert.notEqual(calls[2].redemptionId,calls[3].redemptionId)});
test('SMS send and keyboard submit share one immediate operation',async()=>{const gate=deferred();let calls=0;const h=harness('features/auth/screens/PhoneAuthScreen.tsx',{'../api/phoneAuth':{beginPhoneSignIn:async()=>{calls++;return gate.promise},usesTwoFactorSms:true}});h.find('phone-input').props.onChangeText('9999900001');const press=h.find('send-code').props.onPress,submit=h.find('phone-input').props.onSubmitEditing;const p=[press(),submit(),press()];assert.equal(calls,1);gate.resolve({confirm:async()=>{}});await Promise.all(p)});
test('verification and resend cannot execute competing same-render intents',async()=>{const gate=deferred();let sends=0,verifies=0;const h=harness('features/auth/screens/PhoneAuthScreen.tsx',{'../api/phoneAuth':{beginPhoneSignIn:async()=>{sends++;return{confirm:async()=>{verifies++;return gate.promise}}},usesTwoFactorSms:true}});h.find('phone-input').props.onChangeText('9999900001');await h.find('send-code').props.onPress();h.find('verify-input').props.onChangeText('123456');const verify=h.find('verify').props.onPress,resend=h.label('Send another code').props.onPress;const p=[verify(),resend(),verify()];assert.equal(verifies,1);assert.equal(sends,1);gate.resolve();await Promise.all(p)});
function chat(overrides){const h=harness('features/chat/screens/ChatScreen.tsx',overrides);h.emit({status:'active',userA:'alice',userB:'bob',userAName:'Alice',userBName:'Bob'});return h;}
test('message rapid send invokes one API request, not duplicate transport attempts',async()=>{const gate=deferred();let calls=0;const h=chat({'../api/messages':{sendMessage:async()=>{calls++;return gate.promise}}});h.find('message-input').props.onChangeText('Hello');const press=h.find('send-message').props.onPress,p=[press(),press(),press()];assert.equal(calls,1);gate.resolve({});await Promise.all(p)});
test('end and block share a synchronous destructive-action guard',async()=>{const gate=deferred();const calls=[];const h=chat({'../../connections/api/connections':{endConnection:async()=>{calls.push('end');return gate.promise}},'../../safety/api/reports':{blockUser:async()=>{calls.push('block');return gate.promise}}});h.find('chat-options').props.onPress();const end=h.label('End connection').props.onPress,block=h.label('Block and end connection').props.onPress,p=[end(),block(),end()];assert.deepEqual(calls,['end']);gate.resolve({});await Promise.all(p);assert.equal(h.navigationCalls.length,1)});
test('report rapid submit writes one report and navigates once',async()=>{const gate=deferred();let calls=0;const h=chat({'../../safety/api/reports':{fileReport:async()=>{calls++;return gate.promise}}});h.find('chat-options').props.onPress();h.label('Report and end connection').props.onPress();const press=h.label('Spam or a bot').props.onPress,p=[press(),press(),press()];assert.equal(calls,1);gate.resolve({});await Promise.all(p);assert.equal(h.navigationCalls.length,1)});
test('private-note save suppresses repeated same-render writes',async()=>{const gate=deferred();let calls=0;const h=chat({'../api/chats':{saveNote:async()=>{calls++;return gate.promise}}});h.find('chat-title').props.onPress();h.find('note-input').props.onChangeText('Cafe');const press=h.find('note-save').props.onPress,p=[press(),press(),press()];assert.equal(calls,1);gate.resolve();await Promise.all(p)});
test('age continue and keyboard submit perform one eligibility request',async()=>{const gate=deferred();let calls=0;const h=harness('features/onboarding/screens/AgeCheckScreen.tsx',{'../../account/api/account':{confirmAge:async()=>{calls++;return gate.promise}}});for(const[id,value]of[['age-day','01'],['age-month','01'],['age-year','1990']])h.find(id).props.onChangeText(value);const press=h.find('age-continue').props.onPress,submit=h.find('age-year').props.onSubmitEditing,p=[press(),submit(),press()];assert.equal(calls,1);gate.resolve({confirmed:true});await Promise.all(p);assert.deepEqual(h.results,[true])});
test('deletion recovery does not run overlapping paginated deletion loops',async()=>{const gate=deferred();let calls=0,signouts=0;const h=harness('features/account/DeletionRecoveryScreen.tsx',{'./api/account':{deleteAccount:async()=>{calls++;return gate.promise}},'@react-native-firebase/auth':{signOut:async()=>{signouts++}}});const press=h.find('resume-deletion').props.onPress;press();press();h.label('Sign out').props.onPress();assert.equal(calls,1);assert.equal(signouts,0);gate.resolve();await tick();assert.equal(signouts,1)});
test('profile save is a single same-render operation',async()=>{const gate=deferred();let calls=0;const h=harness('features/settings/screens/SettingsScreen.tsx',{'../../profile/api/profile':{saveDefaultName:async()=>{calls++;return gate.promise}}});await tick();h.find('settings-name').props.onChangeText('Tester');const press=h.label('Save name').props.onPress,p=[press(),press(),press()];assert.equal(calls,1);gate.resolve();await Promise.all(p)});
test('settings sign-out failure is caught and rendered rather than unhandled',async()=>{const h=harness('features/settings/screens/SettingsScreen.tsx',{'@react-native-firebase/auth':{signOut:async()=>{throw Error('offline')}}});await h.find('sign-out').props.onPress();await tick();assert.match(h.texts(),/Could not sign out/)});
for(const action of ['End connection','Block and end connection','Spam or a bot'])test(`failed ${action} releases the safety guard for an explicit retry`,async()=>{let calls=0;const api=async()=>{if(++calls===1)throw Error('offline');return{}};const h=chat({'../../connections/api/connections':{endConnection:api},'../../safety/api/reports':{blockUser:api,fileReport:api}});function press(){h.find('chat-options').props.onPress();if(action==='Spam or a bot')h.label('Report and end connection').props.onPress();return h.label(action).props.onPress()}await press();assert.equal(h.navigationCalls.length,0);await press();assert.equal(calls,2);assert.equal(h.navigationCalls.length,1)});
test('failed message send releases guard but retains the same idempotent message identity',async()=>{const calls=[];const h=chat({'../api/messages':{sendMessage:async data=>{calls.push(data);if(calls.length===1)throw Error('lost response');return{}}}});h.find('message-input').props.onChangeText('Hello');await h.find('send-message').props.onPress();await h.find('send-message').props.onPress();assert.equal(calls.length,2);assert.equal(calls[0].clientMessageId,calls[1].clientMessageId);assert.ok(calls[0].clientMessageId);assert.equal(h.find('message-input').props.value,'')});
test('starting a safety action suppresses a stale send callback immediately',async()=>{const gate=deferred();let messages=0;const h=chat({'../../connections/api/connections':{endConnection:async()=>gate.promise},'../api/messages':{sendMessage:async()=>{messages++;return{}}}});h.find('message-input').props.onChangeText('Not after ending');const send=h.find('send-message').props.onPress;h.find('chat-options').props.onPress();const p=h.label('End connection').props.onPress();await send();assert.equal(messages,0);gate.resolve({});await p});
test('failed note write leaves its draft available for one explicit retry',async()=>{let calls=0;const h=chat({'../api/chats':{saveNote:async()=>{if(++calls===1)throw Error('offline')}}});h.find('chat-title').props.onPress();h.find('note-input').props.onChangeText('Cafe');await h.find('note-save').props.onPress();assert.equal(h.find('note-input').props.value,'Cafe');await h.find('note-save').props.onPress();assert.equal(calls,2)});
test('failed SMS send releases the lock and invalid number does not consume it',async()=>{let calls=0;const h=harness('features/auth/screens/PhoneAuthScreen.tsx',{'../api/phoneAuth':{beginPhoneSignIn:async()=>{if(++calls===1)throw Error('offline');return{confirm:async()=>{}}},usesTwoFactorSms:true}});await h.find('send-code').props.onPress();assert.equal(calls,0);h.find('phone-input').props.onChangeText('9999900001');await h.find('send-code').props.onPress();assert.equal(calls,1);await h.find('send-code').props.onPress();assert.equal(calls,2);assert.ok(h.find('verify-input'))});
test('resending an OTP clears the superseded code and blocks stale verification while sending',async()=>{const gate=deferred();let sends=0,verifies=0;const confirmation={confirm:async()=>{verifies++}};const h=harness('features/auth/screens/PhoneAuthScreen.tsx',{'../api/phoneAuth':{beginPhoneSignIn:async()=>++sends===1?confirmation:gate.promise,usesTwoFactorSms:true}});h.find('phone-input').props.onChangeText('9999900001');await h.find('send-code').props.onPress();h.find('verify-input').props.onChangeText('123456');const verify=h.find('verify').props.onPress;const p=h.label('Send another code').props.onPress();await verify();assert.equal(verifies,0);gate.resolve(confirmation);await p;assert.equal(h.find('verify-input').props.value,'')});
test('failed deletion recovery can be retried without overlapping loops',async()=>{let calls=0;const h=harness('features/account/DeletionRecoveryScreen.tsx',{'./api/account':{deleteAccount:async()=>{if(++calls===1)throw Error('offline')}}});await h.find('resume-deletion').props.onPress();assert.match(h.texts(),/Deletion has not finished/);await h.find('resume-deletion').props.onPress();assert.equal(calls,2)});
test('repeated Delete taps open one dialog and duplicate confirmation runs one deletion',async()=>{const gate=deferred();let calls=0;const h=harness('features/settings/screens/SettingsScreen.tsx',{'../../account/api/account':{deleteAccount:async()=>{calls++;return gate.promise}}});const press=h.find('delete-account').props.onPress;press();press();press();assert.equal(h.alerts.length,1);const confirm=h.alerts[0][2].find(b=>b.style==='destructive').onPress;confirm();confirm();h.find('sign-out').props.onPress();assert.equal(calls,1);gate.resolve();await tick()});
test('cancelled delete confirmation releases dialog ownership without deleting anything',()=>{const h=harness('features/settings/screens/SettingsScreen.tsx');h.find('delete-account').props.onPress();h.alerts[0][2].find(b=>b.style==='cancel').onPress();h.find('delete-account').props.onPress();assert.equal(h.alerts.length,2)});
test('failed settings sign-out can retry without leaving account controls stuck',async()=>{let calls=0;const h=harness('features/settings/screens/SettingsScreen.tsx',{'@react-native-firebase/auth':{signOut:async()=>{if(++calls===1)throw Error('offline')}}});await h.find('sign-out').props.onPress();assert.equal(h.find('sign-out').props.loading,false);await h.find('sign-out').props.onPress();assert.equal(calls,2)});
test('age sign-out failure is handled and eligibility guard is released',async()=>{let calls=0;const h=harness('features/onboarding/screens/AgeCheckScreen.tsx',{'@react-native-firebase/auth':{signOut:async()=>{if(++calls===1)throw Error('offline')}}});await h.label('Sign out').props.onPress();assert.match(h.texts(),/Could not sign out/);await h.label('Sign out').props.onPress();assert.equal(calls,2)});

test('RequestScreen repeated back submits one decline then one successful navigation', { timeout: 2000 }, async () => {
  const pending = deferred();
  const calls = [];
  const h = harness(`${pairing}RequestScreen.tsx`, {
    '../api/connections': {
      respondToRequest: (payload) => {
        calls.push(payload);
        return pending.promise;
      },
    },
  });

  h.back();
  h.back();
  assert.equal(calls.length, 1);
  assert.deepEqual(JSON.parse(JSON.stringify(calls[0])), { requestId: 'request1', accept: false });
  assert.equal(h.navigationCalls.length, 0);

  pending.resolve({});
  await tick();
  h.render();
  assert.equal(calls.length, 1);
  assert.deepEqual(JSON.parse(JSON.stringify(h.navigationCalls)), [['replace', 'Generate']]);
});

test('RequestScreen decline failure stays then explicit retry succeeds', { timeout: 2000 }, async () => {
  const first = deferred();
  const second = deferred();
  const calls = [];
  const h = harness(`${pairing}RequestScreen.tsx`, {
    '../api/connections': {
      respondToRequest: (payload) => {
        calls.push(payload);
        return calls.length === 1 ? first.promise : second.promise;
      },
    },
  });

  h.back();
  first.reject(new Error('network failure'));
  await tick();
  h.render();

  assert.equal(calls.length, 1);
  assert.equal(h.navigationCalls.length, 0);
  assert.match(h.texts(), /Could not respond to the request\. Try again\./);
  assert.equal(h.find('decline').props.disabled, false);

  const retry = h.find('decline').props.onPress();
  second.resolve({});
  await retry;
  await tick();
  h.render();

  assert.equal(calls.length, 2);
  assert.deepEqual(JSON.parse(JSON.stringify(calls[1])), { requestId: 'request1', accept: false });
  assert.deepEqual(JSON.parse(JSON.stringify(h.navigationCalls)), [['replace', 'Generate']]);
});

test('RequestScreen back while accept pending does not decline and navigates once after success', { timeout: 2000 }, async () => {
  const pending = deferred();
  const calls = [];
  const h = harness(`${pairing}RequestScreen.tsx`, {
    '../api/connections': {
      respondToRequest: (payload) => {
        calls.push(payload);
        return pending.promise;
      },
    },
  });

  const acceptPromise = h.find('accept').props.onPress();
  h.back();
  assert.deepEqual(JSON.parse(JSON.stringify(calls)), [{ requestId: 'request1', accept: true }]);
  assert.equal(h.navigationCalls.length, 0);

  pending.resolve({ connectionId: 'chat1' });
  await acceptPromise;
  await tick();
  h.render();

  assert.deepEqual(JSON.parse(JSON.stringify(calls)), [{ requestId: 'request1', accept: true }]);
  assert.deepEqual(JSON.parse(JSON.stringify(h.navigationCalls)), [
    ['reset', { index: 1, routes: [{ name: 'Chats' }, { name: 'Chat', params: { connectionId: 'chat1' } }] }],
  ]);
});

test('RequestScreen explicit decline still navigates once', { timeout: 2000 }, async () => {
  const pending = deferred();
  const calls = [];
  const h = harness(`${pairing}RequestScreen.tsx`, {
    '../api/connections': {
      respondToRequest: (payload) => {
        calls.push(payload);
        return pending.promise;
      },
    },
  });

  const declinePromise = h.find('decline').props.onPress();
  pending.resolve({});
  await declinePromise;
  await tick();
  h.render();

  assert.deepEqual(JSON.parse(JSON.stringify(calls)), [{ requestId: 'request1', accept: false }]);
  assert.deepEqual(JSON.parse(JSON.stringify(h.navigationCalls)), [['replace', 'Generate']]);
});

test('RequestScreen expired/unavailable Start again does not re-decline', { timeout: 2000 }, async () => {
  const calls = [];
  const unavailableHarness = harness(`${pairing}RequestScreen.tsx`, {
    '../api/connections': {
      respondToRequest: async (payload) => {
        calls.push(payload);
        return {};
      },
    },
  });

  unavailableHarness.emit({ status: 'declined' });
  unavailableHarness.find('request-start-again').props.onPress();
  assert.equal(calls.length, 0);
  assert.deepEqual(JSON.parse(JSON.stringify(unavailableHarness.navigationCalls)), [['replace', 'Generate']]);

  const now = Date.now();
  const expiredHarness = harness(`${pairing}RequestScreen.tsx`, {
    '@react-navigation/native': {
      useRoute: () => ({
        params: {
          requestId: 'request1',
          requesterName: 'Peer',
          requestedAt: now - 20000,
          tidCreatedAt: now - 25000,
          expiresAt: now - 1000,
        },
      }),
    },
    '../api/connections': {
      respondToRequest: async (payload) => {
        calls.push(payload);
        return {};
      },
    },
  });

  expiredHarness.find('request-start-again').props.onPress();
  assert.equal(calls.length, 0);
  assert.deepEqual(JSON.parse(JSON.stringify(expiredHarness.navigationCalls)), [['replace', 'Generate']]);
});

test('ChatScreen messageLoadError true to false clears stale message-load error banner', { timeout: 2000 }, async () => {
  let messageError = true;
  const h = harness('features/chat/screens/ChatScreen.tsx', {
    '../api/chats': {
      useNotes: () => ({}),
      useChatMessages: () => ({ messages: [], error: messageError }),
    },
  });

  h.emit({
    status: 'active',
    userA: 'alice',
    userB: 'bob',
    userAName: 'Alice',
    userBName: 'Bob',
    nameA: 'Alice',
    nameB: 'Bob',
    names: { alice: 'Alice', bob: 'Bob' },
  });
  await tick();
  h.render();
  assert.match(h.texts(), /Could not load messages\. Try reopening this chat\./);

  messageError = false;
  h.render();
  await tick();
  h.render();
  assert.doesNotMatch(h.texts(), /Could not load messages\. Try reopening this chat\./);
});

test('ChatScreen messageLoadError recovery preserves unrelated connection error', { timeout: 2000 }, async () => {
  let messageError = true;
  const h = harness('features/chat/screens/ChatScreen.tsx', {
    '../api/chats': {
      useNotes: () => ({}),
      useChatMessages: () => ({ messages: [], error: messageError }),
    },
  });

  h.emit({
    status: 'active',
    userA: 'alice',
    userB: 'bob',
    userAName: 'Alice',
    userBName: 'Bob',
    nameA: 'Alice',
    nameB: 'Bob',
    names: { alice: 'Alice', bob: 'Bob' },
  });
  await tick();
  h.render();
  assert.match(h.texts(), /Could not load messages\. Try reopening this chat\./);

  h.listeners.at(-1).error(new Error('offline'));
  await tick();
  h.render();
  assert.match(h.texts(), /Could not load this connection\./);

  messageError = false;
  h.render();
  await tick();
  h.render();
  assert.match(h.texts(), /Could not load this connection\./);
  assert.doesNotMatch(h.texts(), /Could not load messages\. Try reopening this chat\./);
});
